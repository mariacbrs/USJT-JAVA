package usjt.medicalsys;

public class MedicalSys {

    public static void main(String[] args) {
        
    }
}
