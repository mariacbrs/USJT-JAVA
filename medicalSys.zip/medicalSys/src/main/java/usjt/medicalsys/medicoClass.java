
package usjt.medicalsys;


public class medicoClass extends userClass {
    int medico_id;
    String especialidade;
}
