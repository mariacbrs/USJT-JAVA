
package usjt.medicalsys;

public class userClass {
    int user_id;
    String nome;
    String email;
    String senha;
    String cpf;
    String telefone;
}


