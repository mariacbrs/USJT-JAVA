
package usjt.medicalsys;


public class consultaClass extends userClass {
   String data_hora;
   String descricao;
}
